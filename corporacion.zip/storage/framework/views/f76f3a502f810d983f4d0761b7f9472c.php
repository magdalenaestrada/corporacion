<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <?php echo e(__('TODAS LAS OPERACIONES REGISTRADAS')); ?>

                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('finas.index')); ?>">
                            <?php echo e(__('CREAR NUEVO BLENDING')); ?>

                        </a>
                    </div>
                    <div class="card-body">


                        <table class="table table-striped table-hover text-center mb-0">
                            <?php if(count($finas) > 0): ?>
                                <thead>
                                    <div class="mb-3">
    <input type="text" id="searchInput" class="form-control"
           placeholder="Buscar por ID, código, ticket, estado...">
</div>
                                    <tr>
                                        <th scope="col"><?php echo e(__('ID')); ?></th>
                                        <th scope="col"><?php echo e(__('CODIGO BLENDING')); ?></th>
                                        <th scope="col"><?php echo e(__('NRO TICKET')); ?></th>
                                        <th scope="col"><?php echo e(__('TOTAL TMH')); ?></th>
                                        <th scope="col"><?php echo e(__('PORCENTAJE H2O')); ?></th>
                                        <th scope="col"><?php echo e(__('TOTAL TMS')); ?></th>
                                        <th scope="col"><?php echo e(__('CU PROMEDIO')); ?></th>
                                        <th scope="col"><?php echo e(__('AG PROMEDIO')); ?></th>
                                        <th scope="col"><?php echo e(__('AU PROMEDIO')); ?></th>
                                        <th scope="col"><?php echo e(__('ESTADO')); ?></th>
                                        <th scope="col"><?php echo e(__('ACCIONES')); ?></th>
                                    </tr>
                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $finas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($fina->id); ?></td>
                                                                        <td><?php echo e($fina->codigoBlending); ?></td>
                                                                       <td>
                                                                    <?php if(!empty($fina->tickets_list) && count($fina->tickets_list)): ?>
                                                                        <?php $__currentLoopData = $fina->tickets_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <span class="badge bg-secondary me-1 mb-1"><?php echo e($t); ?></span>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php else: ?>
                                                                        <span class="text-muted">Sin tickets</span>
                                                                    <?php endif; ?>
                                                                </td>
                                        <td><?php echo e($fina->total_tmh); ?></td>
                                        <td><?php echo e($fina->porcentaje_h2o); ?></td>
                                        <td><?php echo e($fina->total_tms); ?></td>
                                        <td><?php echo e(number_format($fina->cu_promedio, 3)); ?></td>
                                        <td><?php echo e(number_format($fina->ag_promedio, 3)); ?></td>
                                        <td><?php echo e(number_format($fina->au_promedio, 3)); ?></td>
                                        
                                        <td><?php echo e($fina->estado ?? 'PROVISIONAL'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('finas.show', $fina->id)); ?>" class="btn btn-secondary btn-sm"><?php echo e(__('VER')); ?></a>
                                            <a href="<?php echo e(route('finas.edit', $fina->id)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('EDITAR')); ?></a>
                                            <a href="<?php echo e(route('fina.print', $fina->id)); ?>" class="btn btn-primary btn-sm" target="_blank">
                                                 🖨️IMPRIMIR
                                            </a>
                                            <form action="<?php echo e(route('finas.destroy', $fina->id)); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"><?php echo e(__('ELIMINAR')); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="17" class="text-center text-muted"><?php echo e(__('No hay datos disponibles')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </table>

                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end">
                                <li class="page-item <?php echo e($finas->currentPage() == 1 ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($finas->previousPageUrl() ?: '#'); ?>"><?php echo e(__('Anterior')); ?></a>
                                </li>
                                <?php for($i = 1; $i <= $finas->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($finas->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($finas->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo e(!$finas->hasMorePages() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($finas->nextPageUrl() ?: '#'); ?>"><?php echo e(__('Siguiente')); ?></a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<style>
.table td .badge {
    font-size: 11px;
    margin: 2px;
    display: inline-block;
    white-space: nowrap;
}
</style>
<?php $__env->startPush('js'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('searchInput');
    const rows = document.querySelectorAll('table tbody tr');

    input.addEventListener('keyup', () => {
        const q = input.value.toLowerCase();
        rows.forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q)
                ? ''
                : 'none';
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/finas/procesadas.blade.php ENDPATH**/ ?>