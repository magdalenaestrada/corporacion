

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Editar Humedad #<?php echo e($humedad->id); ?></h5>
            <a href="<?php echo e(route('humedad.index')); ?>" class="btn btn-danger btn-sm">Volver</a>
        </div>

        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php
                // Total neto desde tu tabla pivot humedad_peso (modelo HumedadPeso)
                $totalAlfa   = (int) $humedad->pesos()->where('origen','A')->sum('neto');
                $totalKilate = (int) $humedad->pesos()->where('origen','K')->sum('neto');
                $totalGlobal = $totalAlfa + $totalKilate;
            ?>

            <div class="text-center mb-3">
                <span class="badge bg-dark" style="font-size:14px;">
                    Total Neto ALFA: <?php echo e(number_format($totalAlfa, 0, '.', ',')); ?>

                </span>
                <span class="badge bg-dark" style="font-size:14px;">
                    Total Neto KILATE: <?php echo e(number_format($totalKilate, 0, '.', ',')); ?>

                </span>
                <span class="badge bg-primary" style="font-size:14px;">
                    TOTAL NETO: <?php echo e(number_format($totalGlobal, 0, '.', ',')); ?>

                </span>
            </div>

            <form action="<?php echo e(route('humedad.update', $humedad->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row g-2">
                    <div class="col-md-3">
                        <label class="text-muted">Mineral</label>
                        <select name="estado_mineral_id" class="form-control" required>
                            <option value="">Seleccione...</option>
                            <?php $__currentLoopData = $minerales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m->id); ?>" <?php echo e(old('estado_mineral_id', $humedad->estado_mineral_id)==$m->id?'selected':''); ?>>
                                    <?php echo e($m->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-5">
                        <label class="text-muted">Razón social</label>
                        <select name="cliente_id" class="form-control" required>
                            <option value="">Seleccione...</option>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($c->id); ?>" <?php echo e(old('cliente_id', $humedad->cliente_id)==$c->id?'selected':''); ?>>
                                    <?php echo e($c->razon_social); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label class="text-muted">Fecha recepción</label>
                        <input type="date" name="fecha_recepcion" class="form-control"
                               value="<?php echo e(old('fecha_recepcion', optional($humedad->fecha_recepcion)->format('Y-m-d'))); ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="text-muted">Fecha emisión</label>
                        <input type="date" name="fecha_emision" class="form-control"
                               value="<?php echo e(old('fecha_emision', optional($humedad->fecha_emision)->format('Y-m-d'))); ?>">
                    </div>
                </div>

                <div class="row g-2 mt-2">
                    <div class="col-md-2">
                        <label class="text-muted">Periodo inicio</label>
                        <input type="date" name="periodo_inicio" class="form-control"
                               value="<?php echo e(old('periodo_inicio', optional($humedad->periodo_inicio)->format('Y-m-d'))); ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="text-muted">Periodo fin</label>
                        <input type="date" name="periodo_fin" class="form-control"
                               value="<?php echo e(old('periodo_fin', optional($humedad->periodo_fin)->format('Y-m-d'))); ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="text-muted">Humedad</label>
                        <input type="number" step="0.01" name="humedad" class="form-control"
                               value="<?php echo e(old('humedad', $humedad->humedad)); ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="text-muted">Observaciones</label>
                        <input type="text" name="observaciones" class="form-control" maxlength="500"
                               value="<?php echo e(old('observaciones', $humedad->observaciones)); ?>">
                    </div>
                </div>

                <div class="text-center mt-3">
                    <button class="btn btn-primary">Actualizar Humedad</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/humedad/edit.blade.php ENDPATH**/ ?>