<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                     <div class="text-center">
                        <?php echo e(__('TODAS LAS OPERACIONES REGISTRADAS')); ?>

                    </div>
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="mb-3 d-flex gap-3">
                            <span class="badge bg-success fs-6">CIERRE: <?php echo e($totalCierre); ?></span>
                            <span class="badge bg-warning text-dark fs-6">PROVISIONAL: <?php echo e($totalProvisional); ?></span>
                            
                            <span class="badge bg-danger fs-6">SIN CIERRE: <?php echo e($totalSinCierre); ?></span>

                        </div>
                       
                        <!-- Modal Ranking 👑 -->
<div class="modal fade" id="modalRanking" tabindex="-1" aria-labelledby="rankingLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content ranking-modal shadow-lg">
            <div class="modal-header bg-dark text-white border-0">
                <h5 class="modal-title" id="rankingLabel">🏅 Ranking de Liquidadores</h5>
                <button type="button" class="btn-close btn-close-white"
                        data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>

            <div class="modal-body bg-dark text-white">
                <div class="d-flex justify-content-around align-items-end gap-3 flex-wrap"
                     style="min-height: 240px;">
                    <?php $max = $conteoCierres->max('count'); ?>

                    <?php $__currentLoopData = $conteoCierres->sortByDesc('count')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $altura = intval(($user['count'] / $max) * 180); // px
                            $rank   = $loop->index + 1;                     // 1-5
                        ?>

                        <div class="bar-wrapper rank-<?php echo e($rank); ?>">
                            
                            <span class="badge rank-badge"><?php echo e($rank); ?></span>

                            
                            <div class="bar" style="height: <?php echo e($altura); ?>px;"></div>

                            
                            <div class="meta">
                                <div class="name" title="<?php echo e($user['name']); ?>"><?php echo e($user['name']); ?></div>
                                <div class="count"><?php echo e($user['count']); ?> cierres</div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="modal-footer bg-dark border-0">
                <button type="button" class="btn btn-outline-light btn-sm"
                        data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<style>
/* Modal look & feel */
.ranking-modal { border-radius: 1rem; overflow: hidden; }

/* Wrapper de cada barra */
.bar-wrapper {
    width: 100px;
    position: relative;
    text-align: center;
}
.bar-wrapper .bar {
    width: 100%;
    border-radius: .5rem .5rem 0 0;
    transition: transform .3s ease, opacity .3s ease;
}
.bar-wrapper:hover .bar { transform: translateY(-4px); }

/* Nombres y números */
.bar-wrapper .meta .name  { font-size: .75rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.bar-wrapper .meta .count { font-size: .75rem; color: #1dd2d2; }

/* Medallas */
.rank-badge {
    position: absolute;
    top: -1.8rem;
    left: 50%;
    transform: translateX(-50%);
    font-size: .8rem;
    padding: .25rem .5rem;
    border-radius: 1rem;
    color: #000;
    font-weight: 700;
}

/* Colores gradientes top-3 + barras normales */
.rank-1 .bar { background: linear-gradient(180deg,#ffec54 0%,#d4a400 100%); }
.rank-2 .bar { background: linear-gradient(180deg,#d9d9d9 0%,#9e9e9e 100%); }
.rank-3 .bar { background: linear-gradient(180deg,#d9995f 0%,#8b5a2b 100%); }
.rank-4 .bar,
.rank-5 .bar { background:#0d6efd; }

.rank-1 .rank-badge { background:#ffec54; }
.rank-2 .rank-badge { background:#d9d9d9; }
.rank-3 .rank-badge { background:#d9995f; }
.rank-4 .rank-badge,
.rank-5 .rank-badge { background:#0d6efd; color:#fff; }
</style>
                       
                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('liquidaciones.create')); ?>">
                            <?php echo e(__('CREAR NUEVO LIQUIDACIONES')); ?>

                        </a>
                    </div>
                    
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('liquidaciones.index')); ?>" class="mb-3">
    <div class="row g-2 align-items-center">
        <div class="col-md-5">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Buscar por muestra, cliente, peso o lote">
        </div>  

        <div class="col-md-2">
            <select name="estado" class="form-select">
                <option value="">🔁 Todos los estados</option>
                <option value="CIERRE" <?php echo e(request('estado') == 'CIERRE' ? 'selected' : ''); ?>>✅ Cierre</option>
                <option value="PROVISIONAL" <?php echo e(request('estado') == 'PROVISIONAL' ? 'selected' : ''); ?>>🟡 Provisional</option>
                <option value="SIN CIERRE" <?php echo e(request('estado') == 'SIN CIERRE' ? 'selected' : ''); ?>>
                    🚫 Sin estado asignado
                </option>
            </select>
        </div>

        <div class="col-md-2">
            <select name="producto" class="form-select">
                <option value="">📦 Todos los productos</option>
                <?php $__currentLoopData = ['CONCENTRADO', 'BLENDING', 'POLVEADO', 'MOLIDO', 'FALCON', 'CHANCADO', 'RELAVE', 'MARTILLADO', 'GRANEL', 'SOBRANTE']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p); ?>" <?php echo e(request('producto') == $p ? 'selected' : ''); ?>><?php echo e($p); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-1 d-flex flex-column">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="filtroOcultarClientes" checked>
                <label class="form-check-label" for="filtroOcultarClientes">
                    Ocultar clientes especiales
                </label>
            </div>
        </div>

        <div class="col-md-2">
            <div class="d-flex gap-2">
                <button class="btn btn-secondary flex-fill" type="submit"><?php echo e(__('Buscar')); ?></button>
                <button type="button" class="btn btn-info flex-fill" data-bs-toggle="modal" data-bs-target="#modalRanking">
                    📊 Ver Ranking
                </button>
            </div>
        </div>
    </div>
</form>
                       
                        <table class="table table table-hover text-center mb-0">
                            <?php if(count($liquidaciones) > 0): ?>
                                <thead>
                                    <tr>
                                        <th scope="col"><?php echo e(__('ID')); ?></th>
                                        <th scope="col"><?php echo e(__('MUESTRA')); ?></th>
                                        <th scope="col"><?php echo e(__('CLIENTE')); ?></th>
                                        <th scope="col"><?php echo e(__('EMPRESA')); ?></th>
                                        <th scope="col"><?php echo e(__('LOTE')); ?></th>
                                        <th scope="col"><?php echo e(__('PESO')); ?></th>
                                        <th scope="col"><?php echo e(__('PRODUCTO')); ?></th>
                                        <th scope="col"><?php echo e(__('ESTADO')); ?></th>
                                        <th scope="col"><?php echo e(__('TICKET')); ?></th>
                                        <th scope="col"><?php echo e(__('TOTAL')); ?></th>
                                        <th scope="col"><?php echo e(__('NOTAS')); ?></th>
                                        <th scope="col"><?php echo e(__('CREADO POR')); ?></th>
                                        <th scope="col"><?php echo e(__('CIERRE FINAL')); ?></th>
                                        <th scope="col"><?php echo e(__('ACCIONES')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $liquidaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liquidacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php if(in_array(strtoupper($liquidacion->cliente->datos_cliente), ['BLENDING', 'CHAVEZ CORNEJO JURGEN LUIS', 'INNOVA CORPORATIVO S.A.'])): ?> fila-cliente-oculta <?php endif; ?>">

                                        <td><?php echo e($liquidacion->id); ?></td>
                                        <td><?php echo e($liquidacion->muestra->codigo); ?></td>
                                        <td><?php echo e($liquidacion->cliente->datos_cliente); ?></td>
                                        <td><?php echo e($liquidacion->cliente->razon_social); ?></td>
                                        <td><?php echo e($liquidacion->lote); ?></td>
                                        <td><?php echo e($liquidacion->peso); ?></td>
                                        <td><?php echo e($liquidacion->producto); ?></td>
                                  <td>
                                    <span class="badge 
                                        <?php echo e($liquidacion->estado=='CIERRE' ? 'bg-success' : 
                                        ($liquidacion->estado=='PROVISIONAL' ? 'bg-warning text-dark' : 'bg-danger')); ?>">
                                        <?php echo e($liquidacion->estado ?? 'SIN CIERRE'); ?>

                                    </span>
                                </td>
                                        <td><?php echo e($liquidacion->NroSalida); ?></td>
                                        <td><?php echo e($liquidacion->total); ?> </td>
                                        <td><?php echo e($liquidacion->comentario); ?></td>
                                        <td><?php echo e($liquidacion->creator->name ?? 'N/A'); ?> (<?php echo e($liquidacion->created_at->format('d/m/Y - H:i:s')); ?>)</td>
                                        <td><?php echo e($liquidacion->lastEditor->name ?? 'N/A'); ?> (<?php echo e($liquidacion->updated_at->format('d/m/Y - H:i:s')); ?>)</td> 
                                       
                                        
                                        <td>
                                            <a href="<?php echo e(route('liquidaciones.show', $liquidacion->id)); ?>" class="btn btn-secondary btn-sm"><?php echo e(__('VER')); ?></a>
                                            
                                            <?php if($liquidacion->estado !== 'CIERRE' && $liquidacion->estado !== 'PROVISIONAL'): ?>
                                                <form action="<?php echo e(route('duplicate', $liquidacion->id)); ?>" method="POST" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-success btn-sm"><?php echo e(__('CIERRE')); ?></button>
                                                </form>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $liquidacion)): ?>
                                            <a href="<?php echo e(route('liquidaciones.edit', parameters: $liquidacion->id)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('EDITAR')); ?></a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('liquidaciones.print', $liquidacion->id)); ?>" class="btn btn-primary btn-sm"><?php echo e(__('IMPRIMIR')); ?></a>
                                            <form action="<?php echo e(route('liquidaciones.destroy', $liquidacion->id)); ?>" method="POST" style="display:inline;" class="form-eliminar">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"><?php echo e(__('ELIMINAR')); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center text-muted"><?php echo e(__('No hay datos disponibles')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </table>

                     <div class="overflow-auto">
    <nav aria-label="Page navigation example">
        <ul class="pagination flex-nowrap">
            <li class="page-item <?php echo e($liquidaciones->onFirstPage() ? 'disabled' : ''); ?>">
                <a class="page-link" href="<?php echo e($liquidaciones->previousPageUrl()); ?>"><?php echo e(__('Anterior')); ?></a>
            </li>

            <?php for($i = 1; $i <= $liquidaciones->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($liquidaciones->currentPage() == $i ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($liquidaciones->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <li class="page-item <?php echo e($liquidaciones->hasMorePages() ? '' : 'disabled'); ?>">
                <a class="page-link" href="<?php echo e($liquidaciones->nextPageUrl()); ?>"><?php echo e(__('Siguiente')); ?></a>
            </li>
        </ul>
    </nav>
</div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <style>
    .overflow-auto {
        overflow-x: auto;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
    }
    .pagination {
        flex-wrap: nowrap;
    }
    .pagination .page-link {
        font-size: 0.85rem;
        padding: 0.3rem 0.6rem;
    }
    thead th{
    position: sticky;
    top: 0;
    z-index: 1;
    background: #fff; /* o #f8f9fa si usas la clase table-light */
}
</style>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const eliminarForms = document.querySelectorAll('.form-eliminar');

        eliminarForms.forEach(form => {
            form.addEventListener('submit', function (e) {
                e.preventDefault(); // Prevenir envío inmediato

                Swal.fire({
                    title: '¿Estás seguro?',
                    text: "¡Esta acción no se puede deshacer!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit(); // Enviar formulario si confirma
                    }
                });
            });
        });
    });
</script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('form[id^="duplicate-form-"]').forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    
                    var button = this.querySelector('button[type="submit"]');
                    button.style.display = 'none';

                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', this.action, true);
                    xhr.setRequestHeader('X-CSRF-TOKEN', this.querySelector('input[name="_token"]').value);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    
                    xhr.onload = function() {
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            alert(response.success ? 'Registro duplicado exitosamente!' : 'Error: ' + response.error);
                        } else {
                            alert('Error en la solicitud: ' + xhr.statusText);
                        }
                        button.style.display = 'inline-block';
                    };
                    
                    xhr.send(new URLSearchParams(new FormData(this)).toString());
                });
            });
        });
    </script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const checkbox = document.getElementById('filtroOcultarClientes');

        function aplicarFiltroClientes() {
            const ocultar = checkbox.checked;
            document.querySelectorAll('.fila-cliente-oculta').forEach(row => {
                row.style.display = ocultar ? 'none' : '';
            });

            // Guardar preferencia en localStorage
            localStorage.setItem('ocultarClientesEspeciales', ocultar ? '1' : '0');
        }

        // Restaurar preferencia al cargar
        const savedPref = localStorage.getItem('ocultarClientesEspeciales');
        if (savedPref !== null) {
            checkbox.checked = savedPref === '1';
        }

        aplicarFiltroClientes(); // aplicar al cargar

        checkbox.addEventListener('change', aplicarFiltroClientes);
    });
</script>

    <?php $__env->stopPush(); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/liquidaciones/index.blade.php ENDPATH**/ ?>