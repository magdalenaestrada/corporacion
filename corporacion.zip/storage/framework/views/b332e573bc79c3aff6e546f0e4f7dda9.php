<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <?php echo e(__('TODAS LAS BLENDINGS REGISTRADAS')); ?>


          <div class="btn-group">
            <a class="btn btn-sm btn-secondary me-2" href="<?php echo e(route('blendings.create')); ?>">
              <?php echo e(__('CREAR NUEVO BLENDINGS')); ?>

            </a>
          </div>
        </div>

        <div class="card-body">
          <!-- Formulario de búsqueda -->
          <div class="mb-3">
            <input type="text" id="searchInput" class="form-control"
              placeholder="Buscar por código, preparación, peso , usuario o nrosalida">
          </div>

          <div class="table-responsive">
            <table class="table table-striped align-middle tabla-blendings" id="blendingsTable">
              <thead>
                <tr>
                  <th><?php echo e(__('ID')); ?></th>
                  <th><?php echo e(__('Fecha Creación')); ?></th>
                  <th><?php echo e(__('Código')); ?></th>
                  <th><?php echo e(__('Preparación')); ?></th>
                  <th><?php echo e(__('Peso')); ?></th>
                  <th><?php echo e(__('Nro Ticket')); ?></th>
                  <th><?php echo e(__('Notas')); ?></th>
                  <th><?php echo e(__('Creado por')); ?></th>
                  <th><?php echo e(__('Estado')); ?></th>
                  <th><?php echo e(__('Acciones')); ?></th>
                </tr>
              </thead>

              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $blendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td><?php echo e($blending->id); ?></td>
                    <td><?php echo e($blending->created_at->format('d-m-Y')); ?></td>
                    <td><?php echo e($blending->cod); ?></td>
                    <td><?php echo e($blending->lista); ?></td>
                    <td><?php echo e($blending->pesoblending); ?></td>

                    
                    <td>
                      <?php
                        $tickets = $blending->ingresos->pluck('NroSalida')->filter()->values();
                        $count = $tickets->count();
                      ?>

                      <?php if($count): ?>
                        <button type="button"
                          class="btn btn-outline-secondary btn-sm ver-tickets"
                          data-tickets="<?php echo e($tickets->implode(',')); ?>">
                          Ver tickets (<?php echo e($count); ?>)
                        </button>

                        
                        <span class="d-none tickets-text"><?php echo e($tickets->implode(' ')); ?></span>
                      <?php else: ?>
                        <span class="text-muted">Sin tickets</span>
                      <?php endif; ?>
                    </td>

                    <td><?php echo e($blending->notas); ?></td>
                    <td><?php echo e($blending->user ? $blending->user->name : 'Desconocido'); ?></td>

                    <td>
                      <span class="badge 
                        <?php if($blending->estado == 'inactivo'): ?> bg-danger
                        <?php elseif($blending->estado == 'despachado'): ?> bg-secondary
                        <?php elseif($blending->estado == 'activo'): ?> bg-success
                        <?php else: ?> bg-primary <?php endif; ?>">
                        <?php echo e(ucfirst($blending->estado)); ?>

                      </span>
                    </td>

                    <td>
                      <a href="<?php echo e(route('blendings.show', $blending->id)); ?>" class="btn btn-secondary btn-sm">VER</a>
                      <a href="<?php echo e(route('blendings.edit', $blending->id)); ?>" class="btn btn-warning btn-sm">EDITAR</a>

                      <?php if($blending->estado !== 'inactivo' && $blending->estado !== 'despachado'): ?>
                        <a href="<?php echo e(route('despachos.create', $blending->id)); ?>" class="btn btn-info btn-sm">DESPACHO</a>
                      <?php endif; ?>

                      <?php if($blending->estado !== 'inactivo'): ?>
                        <form action="<?php echo e(route('blendings.destroy', $blending->id)); ?>" method="POST" class="delete-form" style="display:inline;">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-danger btn-sm delete-btn">ELIMINAR</button>
                        </form>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                    <td colspan="10" class="text-center"><?php echo e(__('No hay blendings disponibles')); ?></td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <nav>
            <ul class="pagination justify-content-center">
              <?php if($blendings->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">« Anterior</span></li>
              <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($blendings->previousPageUrl()); ?>">« Anterior</a></li>
              <?php endif; ?>

              <?php
                $start = max(1, $blendings->currentPage() - 2);
                $end = min($blendings->lastPage(), $blendings->currentPage() + 2);
              ?>

              <?php if($start > 1): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($blendings->url(1)); ?>">1</a></li>
                <?php if($start > 2): ?>
                  <li class="page-item disabled"><span class="page-link">...</span></li>
                <?php endif; ?>
              <?php endif; ?>

              <?php for($i = $start; $i <= $end; $i++): ?>
                <li class="page-item <?php echo e($i == $blendings->currentPage() ? 'active' : ''); ?>">
                  <a class="page-link" href="<?php echo e($blendings->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
              <?php endfor; ?>

              <?php if($end < $blendings->lastPage()): ?>
                <?php if($end < $blendings->lastPage() - 1): ?>
                  <li class="page-item disabled"><span class="page-link">...</span></li>
                <?php endif; ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($blendings->url($blendings->lastPage())); ?>"><?php echo e($blendings->lastPage()); ?></a></li>
              <?php endif; ?>

              <?php if($blendings->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($blendings->nextPageUrl()); ?>">Siguiente »</a></li>
              <?php else: ?>
                <li class="page-item disabled"><span class="page-link">Siguiente »</span></li>
              <?php endif; ?>
            </ul>
          </nav>

        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {

  // Búsqueda en la tabla (incluye tickets aunque visualmente sea "Ver tickets (X)")
  let searchInput = document.getElementById("searchInput");
  searchInput.addEventListener("keyup", function() {
    let filter = searchInput.value.toLowerCase();
    let rows = document.querySelectorAll("#blendingsTable tbody tr");

    rows.forEach(row => {
      let codigo = row.cells[2].textContent.toLowerCase();
      let preparacion = row.cells[3].textContent.toLowerCase();
      let pesoblending = row.cells[4].textContent.toLowerCase();
      let usuario = row.cells[7].textContent.toLowerCase();

      // IMPORTANTE: lee el texto oculto con los tickets si existe
      let ticketsHidden = row.querySelector('.tickets-text');
      let nroSalida = (ticketsHidden ? ticketsHidden.textContent : row.cells[5].textContent).toLowerCase();

      if (codigo.includes(filter) || preparacion.includes(filter) || pesoblending.includes(filter) || usuario.includes(filter) || nroSalida.includes(filter)) {
        row.style.display = "";
      } else {
        row.style.display = "none";
      }
    });
  });

  // Abrir modal de tickets
  document.addEventListener("click", function(e){
    const btn = e.target.closest(".ver-tickets");
    if(!btn) return;

    const tickets = (btn.dataset.tickets || "").split(",").map(t => t.trim()).filter(Boolean);

    Swal.fire({
      title: `Tickets (${tickets.length})`,
      html: `
        <div style="max-height:300px; overflow:auto; text-align:left;">
          ${tickets.map(t => `<span class="badge bg-secondary m-1">${t}</span>`).join("")}
        </div>
      `,
      confirmButtonText: "Cerrar"
    });
  });

  // Confirmación antes de eliminar (con fallback si SweetAlert no cargó)
  document.querySelectorAll(".delete-btn").forEach(button => {
    button.addEventListener("click", function(e) {
      e.preventDefault();
      const form = this.closest(".delete-form");

      if (typeof Swal === 'undefined') {
        if (confirm('¿Estás seguro? ¡Esta acción no se puede deshacer!')) {
          form.submit();
        }
        return;
      }

      Swal.fire({
        title: "¿Estás seguro?",
        text: "¡Esta acción no se puede deshacer!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar"
      }).then((result) => {
        if (result.isConfirmed) {
          form.submit();
        }
      });
    });
  });

});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/blendings/index.blade.php ENDPATH**/ ?>