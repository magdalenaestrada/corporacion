<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row justify-content-between">
                            <div class="col-md-6">
                                <h6 class="mt-2">
                                    <?php echo e(__('VER PESAJE')); ?>

                                </h6>
                            </div>
                            <div class="col-md-6 text-end">
                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('pesos.index')); ?>">
                                    <?php echo e(__('VOLVER')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group">
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>
                                        <?php echo e(__('Estás viendo el Peso NRO')); ?>

                                    </strong>
                                    <span class="badge text-bg-secondary"><?php echo e($peso->NroSalida); ?></span>
                             
                                </div>
                               
                                  
                            </div>

                            



                         



                            <div class="form-group col-md-3 g-3">
                                <label for="Horas">
                                    <?php echo e(__('HORAS')); ?>

                                </label>
                                <?php if($peso->Horas): ?>
                                    <input class="form-control" value="<?php echo e($peso->Horas); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-3 g-3">
                                <label for="Fechas">
                                    <?php echo e(__('FECHAS')); ?>

                                </label>
                                <?php if($peso->Fechas): ?>
                                    <input class="form-control" value="<?php echo e($peso->Fechas); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-3 g-3">
                                <label for="Fechai">
                                    <?php echo e(__('FECHAI')); ?>

                                </label>
                                <?php if($peso->Fechas): ?>
                                    <input class="form-control" value="<?php echo e($peso->Fechai); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-3  g-3">
                                <label for="Horai">
                                    <?php echo e(__('HORAI')); ?>

                                </label>
                                <?php if($peso->Horai): ?>
                                    <input class="form-control" value="<?php echo e($peso->Horai); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>



                            <div class="form-group col-md-2 g-4">
                                <label for="Pesoi">
                                    <?php echo e(__('PESOI')); ?>

                                </label>
                                <?php if($peso->Pesoi): ?>
                                    <input class="form-control" value="<?php echo e($peso->Pesoi); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-2 g-4">
                                <label for="Pesos">
                                    <?php echo e(__('PESOS')); ?>

                                </label>
                                <?php if($peso->Pesos): ?>
                                    <input class="form-control" value="<?php echo e($peso->Pesos); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-2 g-4">
                                <label for="Bruto">
                                    <?php echo e(__('BRUTO')); ?>

                                </label>
                                <?php if($peso->Bruto): ?>
                                    <input class="form-control" value="<?php echo e($peso->Bruto); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-2 g-4">
                                <label for="Tara">
                                    <?php echo e(__('TARA')); ?>

                                </label>
                                <?php if($peso->Tara): ?>
                                    <input class="form-control" value="<?php echo e($peso->Tara); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>
                           

                            <div class="form-group col-md-2 g-4">
                                <label for="Neto">
                                    <?php echo e(__('NETO')); ?>

                                </label>
                                <?php if($peso->Neto): ?>
                                    <input class="form-control" value="<?php echo e($peso->Neto); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            

                            <div class="form-group col-md-6 g-4">
                                <label for="Placa">
                                    <?php echo e(__('PLACA')); ?>

                                </label>
                                <?php if($peso->Placa): ?>
                                    <input class="form-control" value="<?php echo e($peso->Placa); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-6 g-4">
                                <label for="Observacion">
                                    <?php echo e(__('OBSERVACION')); ?>

                                </label>
                                <?php if($peso->Placa): ?>
                                    <input class="form-control" value="<?php echo e($peso->Observacion); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-3 g-4">
                                <label for="Producto">
                                    <?php echo e(__('PRODUCTO')); ?>

                                </label>
                                <?php if($peso->Producto): ?>
                                    <input class="form-control" value="<?php echo e($peso->Producto); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-3 g-4">
                                <label for="Conductor">
                                    <?php echo e(__('CONDUCTOR')); ?>

                                </label>
                                <?php if($peso->Conductor): ?>
                                    <input class="form-control" value="<?php echo e($peso->Conductor); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-3 g-4">
                                <label for="Transportista">
                                    <?php echo e(__('TRANSPORTISTA')); ?>

                                </label>
                                <?php if($peso->Transportista): ?>
                                    <input class="form-control" value="<?php echo e($peso->Transportista); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-3 g-4">
                                <label for="RazonSocial">
                                    <?php echo e(__('RAZON SOCIAL')); ?>

                                </label>
                                <?php if($peso->RazonSocial): ?>
                                    <input class="form-control" value="<?php echo e($peso->RazonSocial); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-6 g-4">
                                <label for="Operadori">
                                    <?php echo e(__('OPERADORI')); ?>

                                </label>
                                <?php if($peso->Operadori): ?>
                                    <input class="form-control" value="<?php echo e($peso->Operadori); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="Destarado">
                                    <?php echo e(__('DESTARADO')); ?>

                                </label>
                                <?php if($peso->Destarado): ?>
                                    <input class="form-control" value="<?php echo e($peso->Destarado); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="Operadors">
                                    <?php echo e(__('OPERADORS')); ?>

                                </label>
                                <?php if($peso->Operadors): ?>
                                    <input class="form-control" value="<?php echo e($peso->Operadors); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="carreta">
                                    <?php echo e(__('CARRETA')); ?>

                                </label>
                                <?php if($peso->carreta): ?>
                                    <input class="form-control" value="<?php echo e($peso->carreta); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="guia">
                                    <?php echo e(__('GUIA')); ?>

                                </label>
                                <?php if($peso->guia): ?>
                                    <input class="form-control" value="<?php echo e($peso->guia); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>



                            <div class="form-group col-md-6 g-4">
                                <label for="guiat">
                                    <?php echo e(__('GUIAT')); ?>

                                </label>
                                <?php if($peso->guiat): ?>
                                    <input class="form-control" value="<?php echo e($peso->guiat); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="pedido">
                                    <?php echo e(__('PEDIDO')); ?>

                                </label>
                                <?php if($peso->pedido): ?>
                                    <input class="form-control" value="<?php echo e($peso->pedido); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>



                            <div class="form-group col-md-6 g-4">
                                <label for="entrega">
                                    <?php echo e(__('ENTREGA')); ?>

                                </label>
                                <?php if($peso->entrega): ?>
                                    <input class="form-control" value="<?php echo e($peso->entrega); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="um">
                                    <?php echo e(__('UM')); ?>

                                </label>
                                <?php if($peso->entrega): ?>
                                    <input class="form-control" value="<?php echo e($peso->um); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-6 g-4">
                                <label for="pesoguia">
                                    <?php echo e(__('PESOGUIA')); ?>

                                </label>
                                <?php if($peso->pesoguia): ?>
                                    <input class="form-control" value="<?php echo e($peso->pesoguia); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="rucr">
                                    <?php echo e(__('RUCR')); ?>

                                </label>
                                <?php if($peso->pesoguia): ?>
                                    <input class="form-control" value="<?php echo e($peso->rucr); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-6 g-4">
                                <label for="ruct">
                                    <?php echo e(__('RUCT')); ?>

                                </label>
                                <?php if($peso->pesoguia): ?>
                                    <input class="form-control" value="<?php echo e($peso->ruct); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="destino">
                                    <?php echo e(__('DESTINO')); ?>

                                </label>
                                <?php if($peso->destino): ?>
                                    <input class="form-control" value="<?php echo e($peso->destino); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="origen">
                                    <?php echo e(__('ORIGEN')); ?>

                                </label>
                                <?php if($peso->origen): ?>
                                    <input class="form-control" value="<?php echo e($peso->origen); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="brevete">
                                    <?php echo e(__('BREVETE')); ?>

                                </label>
                                <?php if($peso->brevete): ?>
                                    <input class="form-control" value="<?php echo e($peso->brevete); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="pbmax">
                                    <?php echo e(__('PBMAX')); ?>

                                </label>
                                <?php if($peso->pbmax): ?>
                                    <input class="form-control" value="<?php echo e($peso->pbmax); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-6 g-4">
                                <label for="tipo">
                                    <?php echo e(__('TIPO')); ?>

                                </label>
                                <?php if($peso->tipo): ?>
                                    <input class="form-control" value="<?php echo e($peso->tipo); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 


                            <div class="form-group col-md-6 g-4">
                                <label for="centro">
                                    <?php echo e(__('CENTRO')); ?>

                                </label>
                                <?php if($peso->tipo): ?>
                                    <input class="form-control" value="<?php echo e($peso->centro); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 


                            <div class="form-group col-md-6 g-4">
                                <label for="nia">
                                    <?php echo e(__('NIA')); ?>

                                </label>
                                <?php if($peso->nia): ?>
                                    <input class="form-control" value="<?php echo e($peso->nia); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 


                            <div class="form-group col-md-6 g-4">
                                <label for="bodega">
                                    <?php echo e(__('BODEGA')); ?>

                                </label>
                                <?php if($peso->bodega): ?>
                                    <input class="form-control" value="<?php echo e($peso->bodega); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 


                            
                            <div class="form-group col-md-6 g-4">
                                <label for="ip">
                                    <?php echo e(__('IP')); ?>

                                </label>
                                <?php if($peso->ip): ?>
                                    <input class="form-control" value="<?php echo e($peso->ip); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 



                            <div class="form-group col-md-6 g-4">
                                <label for="anular">
                                    <?php echo e(__('ANULAR')); ?>

                                </label>
                                <?php if($peso->anular): ?>
                                    <input class="form-control" value="<?php echo e($peso->anular); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 



                            <div class="form-group col-md-6 g-4">
                                <label for="eje">
                                    <?php echo e(__('EJE')); ?>

                                </label>
                                <?php if($peso->eje): ?>
                                    <input class="form-control" value="<?php echo e($peso->eje); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 


                            <div class="form-group col-md-6 g-4">
                                <label for="pesaje">
                                    <?php echo e(__('PESAJE')); ?>

                                </label>
                                <?php if($peso->pesaje): ?>
                                    <input class="form-control" value="<?php echo e($peso->pesaje); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" value="<?php echo e(__('No hay datos disponibles')); ?>" disabled>
                                <?php endif; ?>
                            </div> 


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/pesos/show.blade.php ENDPATH**/ ?>