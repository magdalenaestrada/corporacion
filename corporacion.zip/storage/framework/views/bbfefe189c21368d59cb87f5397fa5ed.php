<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <?php echo e(__('TODAS LAS MUESTRAS REGISTRADAS')); ?>

                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('muestras.create')); ?>">
                            <?php echo e(__('CREAR NUEVA MUESTRA')); ?>

                        </a>
                        <form method="GET" action="<?php echo e(route('muestras.index')); ?>" class="mb-4">
                            <div class="form-row align-items-end">
                                <div class="col">
                                    <div class="input-group">
                                        <input type="text" name="codigo" class="form-control" placeholder="Buscar por codigo..." value="<?php echo e(request('codigo')); ?>">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-primary btn-sm">Buscar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-hover">
                            <?php if(count($muestras) > 0): ?>
                            <thead>
                                <tr>
                                    <th scope="col"><?php echo e(__('ID')); ?></th>
                                    <th scope="col"><?php echo e(__('CODIGO')); ?></th>
                                    <th scope="col"><?php echo e(__('FECHA CREACION')); ?></th>
                                    <th scope="col"><?php echo e(__('COBRE')); ?></th>
                                    <th scope="col"><?php echo e(__('PLATA')); ?></th>
                                    <th scope="col"><?php echo e(__('ORO')); ?></th>
                                    <th scope="col"><?php echo e(__('CREADO POR:')); ?></th>
                                    <th scope="col"><?php echo e(__('ESTADO:')); ?></th>
                                    <th scope="col"><?php echo e(__('ACCION')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $muestras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muestra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($muestra->id); ?></td>
                                        <td><?php echo e($muestra->codigo); ?></td>
                                        <td><?php echo e(($muestra->created_at)->format('d/m/Y - H:i:s')); ?></td>   
                                        <td><?php echo e($muestra->cu); ?></td>
                                        <td><?php echo e($muestra->ag); ?></td>
                                        <td><?php echo e($muestra->au); ?></td>
                                        <td><?php echo e($muestra->user->name); ?></td>
                                        <td><?php echo e($muestra->est); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('muestras.show', $muestra->id)); ?>" class="btn btn-secondary btn-sm"><?php echo e(__('VER')); ?></a>
                                            <a href="<?php echo e(route('muestras.edit', $muestra->id)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('EDITAR')); ?></a>
                                            <form class="eliminar-muestras" action="<?php echo e(route('muestras.destroy', $muestra->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"><?php echo e(__('ELIMINAR')); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted"><?php echo e(__('No hay datos disponibles')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </table>

                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <li class="page-item <?php echo e($muestras->onFirstPage() ? 'disabled' : ''); ?>">
                                <a class="page-link" href="<?php echo e($muestras->previousPageUrl()); ?>"><?php echo e(__('Anterior')); ?></a>
                            </li>
                            <?php for($i = 1; $i <= $muestras->lastPage(); $i++): ?>
                                <li class="page-item <?php echo e($muestras->currentPage() == $i ? 'active' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($muestras->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo e($muestras->hasMorePages() ? '' : 'disabled'); ?>">
                                <a class="page-link" href="<?php echo e($muestras->nextPageUrl()); ?>"><?php echo e(__('Siguiente')); ?></a>
                            </li>
                        </ul>
                    </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            <?php if(session('eliminar-registro')): ?>
                Swal.fire('Registro', 'eliminado exitosamente.', 'success');
            <?php endif; ?>
            <?php if(session('error')): ?>
                Swal.fire({
                    title: 'Error',
                    text: '<?php echo e(session('error')); ?>',
                    icon: 'error',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK'
                });
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/muestras/index.blade.php ENDPATH**/ ?>