

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Humedades</h5>
            <a href="<?php echo e(route('humedad.create')); ?>" class="btn btn-primary btn-sm">Nueva Humedad</a>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success mb-2"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if(session('info')): ?>
                <div class="alert alert-info mb-2"><?php echo e(session('info')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Mineral</th>
                            <th>Fecha recepción</th>
                            <th>Periodo</th>
                            <th>Fecha emisión</th>
                            <th>Razón social</th>
                            <th>Humedad</th>
                            <th>Peso (W)</th>
                            <th>Obs.</th>
                            <th>Tickets</th>
                            <th style="width:220px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $humedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $pesoTotal = $h->pesos->sum(fn($p) => (int)$p->neto);

                            $periodoTexto = ($h->periodo_inicio && $h->periodo_fin)
                                ? \Carbon\Carbon::parse($h->periodo_inicio)->format('d/m/Y') . ' AL ' . \Carbon\Carbon::parse($h->periodo_fin)->format('d/m/Y')
                                : '';
                        ?>
                        <tr>
                            <td>
                                <span class="badge bg-dark">
                                    <?php echo e($h->codigo ?? $h->id); ?>

                                </span>
                            </td>
                            <td><?php echo e($h->mineral->nombre ?? ''); ?></td>
                            <td><?php echo e($h->fecha_recepcion ? \Carbon\Carbon::parse($h->fecha_recepcion)->format('d/m/Y') : ''); ?></td>
                            <td><?php echo e($periodoTexto); ?></td>
                            <td><?php echo e($h->fecha_emision ? \Carbon\Carbon::parse($h->fecha_emision)->format('d/m/Y') : ''); ?></td>
                            <td><?php echo e($h->cliente->razon_social ?? ''); ?></td>
                            <td><?php echo e($h->humedad ?? ''); ?></td>
                            <td><?php echo e(number_format($pesoTotal, 0, '.', ',')); ?></td>
                            <td style="max-width:240px;">
                                <div style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                    <?php echo e($h->observaciones ?? ''); ?>

                                </div>
                            </td>
                            <td style="min-width:220px;">
                                <?php $__currentLoopData = $h->pesos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-secondary me-1 mb-1">
                                        <?php echo e($p->nro_salida); ?> - <?php echo e($p->origen); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td style="white-space:nowrap;">
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('humedad.show', $h->id)); ?>">Ver</a>
                                <a class="btn btn-warning btn-sm" href="<?php echo e(route('humedad.edit', $h->id)); ?>">Editar</a>

                                <a href="<?php echo e(route('humedad.informe', $h->id)); ?>"
                                   class="btn btn-sm btn-secondary"
                                   target="_blank"
                                   title="Ver informe">
                                    Informe
                                </a>

                                <form action="<?php echo e(route('humedad.destroy', $h->id)); ?>"
                                      method="POST"
                                      class="d-inline form-eliminar">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        Eliminar
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="11" class="text-center">Sin registros</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-2">
                <?php echo e($humedades->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.form-eliminar').forEach(form => {
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            Swal.fire({
                title: '¿Estás seguro?',
                text: '¡Esta acción no se puede deshacer!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/humedad/index.blade.php ENDPATH**/ ?>