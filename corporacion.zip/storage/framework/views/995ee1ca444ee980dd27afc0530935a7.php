<div class="container mt-3">
    <a href="<?php echo e(url('roles')); ?>" class="btn btn-primary mx-2">Roles</a>
    <a href="<?php echo e(url('permissions')); ?>" class="btn btn-info mx-2">Permissions</a>
    <a href="<?php echo e(url('users')); ?>" class="btn btn-warning mx-2">Users</a>
</div><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/role-permission/nav-links.blade.php ENDPATH**/ ?>