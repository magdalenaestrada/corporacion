<?php $__env->startSection('content'); ?>
<style>
      html, body {
        height: 100%;
        background-color: #0f172a;
        margin: 0;
        padding: 0;
    }

    #default-sidebar, #toggleSidebarBtn {
        display: none !important; /* Ocultar la barra izquierda */
    }

    

    .login-card {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(10px);
    border-radius: 16px;
    padding: 30px;
    width: 120%;
    max-width: 500px; 
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    color: #e2e8f0;
    text-align: center;
}
    .login-card label {
        color: #e2e8f0;
    }

    .form-control {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid #4b5563;
        color: #fff;
    }

    .form-control:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: #60a5fa;
        color: #fff;
        box-shadow: none;
    }

    .btn-primary {
        background-color: #3b82f6;
        border-color: #3b82f6;
    }

    .btn-primary:hover {
        background-color: #2563eb;
        border-color: #2563eb;
    }

    .btn-link {
        color: #93c5fd;
    }

    .btn-link:hover {
        color: #bfdbfe;
    }

    .invalid-feedback {
        color: #f87171;
    }

    .login-logo {
        width: 100px;
        height: auto;
        margin-bottom: 20px;
    }
</style>

<div class="position-absolute top-50 start-50 translate-middle">
    <div class="login-card">
        <!-- Logo centrado arriba del login -->
        <img src="<?php echo e(asset('images/innovalogo.png')); ?>" alt="Innova Logo" class="login-logo">
        
        <h4 class="mb-4"><?php echo e(__('INNOVA CORPORATIVO')); ?></h4>
        
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3 text-start">
                <label for="email" class="form-label"><?php echo e(__('Correo electrónico')); ?></label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3 text-start">
                <label for="password" class="form-label"><?php echo e(__('Contraseña')); ?></label>
                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       name="password" required autocomplete="current-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3 form-check text-start">
                <input class="form-check-input" type="checkbox" name="remember" id="remember"
                       <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label class="form-check-label" for="remember">
                    <?php echo e(__('Mantener sesión activa')); ?>

                </label>
            </div>

            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Iniciar sesión')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/auth/login.blade.php ENDPATH**/ ?>