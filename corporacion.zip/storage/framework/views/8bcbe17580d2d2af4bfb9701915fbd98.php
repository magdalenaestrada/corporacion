<?php $__empty_1 = true; $__currentLoopData = $pesos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
        $tieneRecepcion = isset($recepcionesPorSalida[$peso->NroSalida]);
        $fechaOk = filled($peso->Fechas);
        $horaOk = filled($peso->Horas);
        $recepcionId = $recepcionesPorSalida[$peso->NroSalida] ?? null;
    ?>

    <tr>
        <td><?php echo e($peso->NroSalida); ?></td>
        <td><?php echo e($peso->Horas ? \Carbon\Carbon::parse($peso->Horas)->format('H:i:s') : '—'); ?></td>
        <td><?php echo e($peso->Fechas ? \Carbon\Carbon::parse($peso->Fechas)->format('d/m/Y') : '—'); ?></td>
        <td><?php echo e($peso->Neto); ?></td>
        <td><?php echo e($peso->Placa); ?></td>
        <td><?php echo e($peso->Producto); ?></td>
        <td><?php echo e($peso->RazonSocial); ?></td>
        <td><?php echo e($peso->destino); ?></td>
        <td><?php echo e($peso->origen); ?></td>

            <td class="text-nowrap" id="acciones-<?php echo e($peso->NroSalida); ?>">
                
                <a href="<?php echo e(route('pesos.show', $peso->NroSalida)); ?>" class="btn btn-secondary btn-xs">
                    Ver
                </a>

                <?php if($tieneRecepcion): ?>
                    <a href="<?php echo e(route('recepciones-ingreso.acta.html', $peso->NroSalida)); ?>"
                    class="btn btn-outline-dark btn-xs" target="_blank" rel="noopener">
                        🖨️ Acta
                    </a>
                <?php endif; ?>

                <?php if(!$tieneRecepcion && $fechaOk && $horaOk): ?>
                    <a href="<?php echo e(route('pesos.recepcionar', $peso->NroSalida)); ?>" class="btn btn-primary btn-xs">
                        📥 Recepción
                    </a>
                <?php endif; ?>

                <?php if($recepcionId): ?>
                    <a href="<?php echo e(route('recepciones-ingreso.edit', $recepcionId)); ?>"
                    class="btn btn-outline-secondary btn-xs">
                        ✏️ Editar
                    </a>

                    
                    <button type="button"
                            class="btn btn-outline-danger btn-xs js-del-recepcion"
                            data-url="<?php echo e(route('recepciones-ingreso.destroy', $recepcionId)); ?>"
                            data-nro="<?php echo e($peso->NroSalida); ?>">
                        🗑️ Eliminar
                    </button>
                <?php endif; ?>
            </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="10" class="text-center text-muted">
            Sin resultados
        </td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\corporacion\resources\views/pesos/partials/tabla.blade.php ENDPATH**/ ?>