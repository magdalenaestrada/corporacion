<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <?php echo e(__('TODOS LOS DESPACHOS REGISTRADOS')); ?>

                </div>

                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>TMH</th>
                                <th>Falta (-) y Excede (+)</th>
                                <th>Deposito</th>
                                <th>Destino</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $despachos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $despacho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($despacho->fecha); ?></td>
                                    <td><?php echo e($despacho->id); ?></td>
                                   <td><?php echo e(optional($despacho->blending)->cod ?? 'Sin blending'); ?></td>
                                    <td><?php echo e($despacho->totalTMH); ?></td>
                                    <td><?php echo e($despacho->masomenos); ?></td>
                                    <td><?php echo e($despacho->deposito); ?></td>
                                    <td><?php echo e($despacho->destino); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('despachos.show', $despacho->id)); ?>" class="btn btn-secondary btn-sm">Ver</a>
                                        <a href="<?php echo e(route('despachos.edit', $despacho->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                                        <?php if($despacho->retiros->count() > 0): ?> 
                                        <?php
                                            $pendientes = $despacho->retiros->whereNull('recepcion')->count();
                                        ?>
                                
                                        <a href="<?php echo e(route('despachos.retiros', $despacho->id)); ?>" 
                                           class="btn btn-sm <?php echo e($pendientes > 0 ? 'btn-info' : 'btn-success'); ?>">
                                            <?php echo e($pendientes > 0 ? 'Retiros' : 'Recepcionados'); ?>

                                        </a>
                                    <?php endif; ?>
                                        <!-- Botón de eliminar con SweetAlert2 -->
                                        <form action="<?php echo e(route('despachos.destroy', $despacho->id)); ?>" method="POST" class="delete-form" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-danger btn-sm delete-btn">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center"><?php echo e(__('No hay despachos disponibles')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll(".delete-btn").forEach(button => {
            button.addEventListener("click", function() {
                let form = this.closest(".delete-form");

                Swal.fire({
                    title: "¿Estás seguro?",
                    text: "¡Esta acción no se puede deshacer!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#d33",
                    cancelButtonColor: "#3085d6",
                    confirmButtonText: "Sí, eliminar",
                    cancelButtonText: "Cancelar"
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit(); // Enviar el formulario si se confirma
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/despachos/index.blade.php ENDPATH**/ ?>