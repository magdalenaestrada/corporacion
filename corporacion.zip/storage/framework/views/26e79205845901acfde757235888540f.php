

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">Nuevo Estado Mineral</div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('estados_mineral.store')); ?>">
                <?php echo csrf_field(); ?>

                <label>Nombre</label>
                <input type="text" name="nombre" class="form-control" required>

                <div class="mt-3 text-end">
                    <button class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/estados_mineral/create.blade.php ENDPATH**/ ?>