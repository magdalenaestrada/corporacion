<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <?php echo e(__('TODAS LAS OPERACIONES REGISTRADAS')); ?>

                        
                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route('clientes.create')); ?>">
                                <?php echo e(__('CREAR NUEVO CLIENTE')); ?>

                            </a>
                            <form method="GET" action="<?php echo e(route('clientes.index')); ?>" class="mb-4">
                                <div class="form-row align-items-end">
                                    <div class="col">
                                        <div class="input-group">
                                            <input type="text" name="filtro" class="form-control" placeholder="Buscar" value="<?php echo e(request('filtro')); ?>">
                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-primary btn-sm">Buscar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-hover">
                            <?php if(count($clientes) > 0): ?>
                            <thead>
                                <tr>
                                    <th scope="col">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('DNI')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('CLIENTE')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('RUC')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('RAZON SOCIAL')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('FECHA CREACION')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Acción')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row">
                                            <?php echo e($cliente->id); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($cliente->documento_cliente); ?>

                                        </td>

                                        <td scope="row">
                                            <?php echo e($cliente->datos_cliente); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($cliente->ruc_empresa); ?>

                                        </td>

                                        <td scope="row">
                                            <?php echo e($cliente->razon_social); ?>

                                        </td>                                                                                                
                                        <td scope="row">
                                            <?php echo e(($cliente->created_at)->format('d/m/Y - H:i:s')); ?>

                                        </td>

                                        <td> 
                                            <a href="<?php echo e(route('clientes.show', $cliente->id)); ?>" class="btn btn-secondary btn-sm">
                                                <?php echo e(__('VER')); ?>

                                            </a>
                                           
                                            <a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning btn-sm">
                                                <?php echo e(__('EDITAR')); ?>

                                            </a>
                                            <form class="eliminar-clientes" action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('¿Estás seguro de que quieres eliminar este cliente?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <?php echo e(__('ELIMINAR')); ?>

                                                </button>
                                            </form>
                                           
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted">
                                        <?php echo e(__('No hay datos disponibles')); ?> 
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end">
                                <li class="page-item <?php echo e($clientes->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($clientes->previousPageUrl()); ?>">
                                        <?php echo e(__('Anterior')); ?>

                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $clientes->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($clientes->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($clientes->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo e($clientes->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link" href="<?php echo e($clientes->nextPageUrl()); ?>">
                                        <?php echo e(__('Siguiente')); ?>

                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            <?php if(session('eliminar-registro') == 'Registro eliminado con éxito.'): ?>
                Swal.fire('Registro', 'eliminado exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('crear-registro') == 'Registro creado con éxito.'): ?>
                Swal.fire('Registro', 'creado exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('editar-registro') == 'Registro actualizado con éxito.'): ?>
                Swal.fire('Registro', 'actualizado exitosamente.', 'success')
            <?php endif; ?>
        </script>
        <script>
            $('.eliminar-registro').submit(function(e){
                e.preventDefault();
                Swal.fire({
                    title: '¿Eliminar registro?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, continuar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        this.submit();
                    }
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/clientes/index.blade.php ENDPATH**/ ?>