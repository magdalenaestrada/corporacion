

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Detalle Humedad #<?php echo e($humedad->id); ?></h5>
            <a href="<?php echo e(route('humedad.index')); ?>" class="btn btn-danger btn-sm">Volver</a>
        </div>

        <div class="card-body">
            <div class="row g-2">
                <div class="col-md-3"><b>Mineral:</b> <?php echo e($humedad->mineral->nombre ?? ''); ?></div>
                <div class="col-md-5"><b>Razón social:</b>  <?php echo e($humedad->cliente->razon_social ?? ''); ?>

    <?php echo e(!empty($humedad->cliente_detalle) ? ' - '.$humedad->cliente_detalle : ''); ?></div>
                <div class="col-md-2"><b>Recepción:</b> <?php echo e($humedad->fecha_recepcion); ?></div>
                <div class="col-md-2"><b>Emisión:</b> <?php echo e($humedad->fecha_emision); ?></div>
                <div class="col-md-4"><b>Periodo:</b> <?php echo e($humedad->periodo_inicio); ?> AL <?php echo e($humedad->periodo_fin); ?></div>
                <div class="col-md-2"><b>Humedad:</b> <?php echo e($humedad->humedad); ?></div>
                <div class="col-md-12"><b>Obs:</b> <?php echo e($humedad->observaciones); ?></div>
            </div>

            <hr>

            <h6>Tickets asociados</h6>
            <div class="mb-2">
                <?php $__currentLoopData = $humedad->pesos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge bg-secondary me-1"><?php echo e($p->nro_salida); ?> - <?php echo e($p->origen); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <h6>ALFA</h6>
                    <ul>
                        <?php $__empty_1 = true; $__currentLoopData = $alfaTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><?php echo e($t->NroSalida); ?> - Neto: <?php echo e($t->Neto); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>Sin tickets ALFA</li>
                        <?php endif; ?>
                    </ul>
                </div>

                <div class="col-md-6">
                    <h6>KILATE</h6>
                    <ul>
                        <?php $__empty_1 = true; $__currentLoopData = $kilateTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><?php echo e($t->NroSalida); ?> - Neto: <?php echo e($t->Neto); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>Sin tickets KILATE</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/humedad/show.blade.php ENDPATH**/ ?>