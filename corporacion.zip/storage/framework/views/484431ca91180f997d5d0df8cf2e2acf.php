    

    <?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div>
                                <?php echo e(__('TODAS LAS OPERACIONES REGISTRADAS')); ?> 
                            </div>
                            <div class="text-center w-200">
                            
                                <span class="badge bg-info  text-black fs-10 p-2">
                                    <?php echo e(__('Peso Total: ')); ?> <?php echo e(number_format($pesoTotal, 3)); ?> 
                                </span>
                                <span class="badge bg-success text-black fs-10 p-2">
                                    <?php echo e(__('Peso Ingresados: ')); ?> <?php echo e(number_format($pesoIngresados, 3)); ?>

                                </span>
                                <span class="badge bg-warning fs-10 p-2 text-dark">
                                    <?php echo e(__('Peso Blending: ')); ?> <?php echo e(number_format($pesoBlending, 3)); ?>

                                </span>
                                <span class="badge bg-danger text-black fs-10 p-2">
                                    <?php echo e(__('Peso Despachado: ')); ?> <?php echo e(number_format($pesoDespachado, 3)); ?>

                                </span>
                                <span class="badge bg-white text-black fs-10 p-2">
                                    <?php echo e(__('Peso Retirado: ')); ?> <?php echo e(number_format($pesoRetirado, 3)); ?>

                                </span>
                                <span class="badge bg-primary text-black fs-10 p-2">
                                    <?php echo e(__('Peso en Stock: ')); ?> <?php echo e(number_format($pesoEnStock, 3)); ?>

                                </span>
                            </div>
                            <div class="btn-group">
                                <a class="btn btn-sm btn-secondary me-2" href="<?php echo e(route('ingresos.create')); ?>">
                                    <?php echo e(__('CREAR NUEVO INGRESO')); ?>

                                </a>
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('ingresos.soloChancado')); ?>">
                                    VER SOLO CHANCADO
                                </a>
                            </div>
                        </div>
                        
                        <div class="card-body">
                            <!-- Formulario de búsqueda -->
                            <form method="GET" action="<?php echo e(route('ingresos.index')); ?>" class="mb-3">
                                <div class="row">
                                    <div class="col-md-3">
                                        <input type="text" name="search" class="form-control" placeholder="Buscar..." value="<?php echo e(request()->get('search')); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <select name="fase" class="form-control">
                                            <option value=""><?php echo e(__('Filtrar por Fase')); ?></option>
                                            <?php $__currentLoopData = $fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($fase); ?>" <?php echo e(request()->get('fase') == $fase ? 'selected' : ''); ?>>
                                                    <?php echo e(ucfirst($fase)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn btn-primary" type="submit"><?php echo e(__('Filtrar')); ?></button>
                                    </div>
                                </div>
                            </form>

                            <!-- Tabla de registros -->
                           <div class="table-responsive">
                     <table class="table table-striped table-hover text-center mb-0 align-middle tabla-ingresos">

                                <thead>
                                    <tr>
                                        <th>#</th>
                                       <!-- <th><?php echo e(__('ID')); ?></th>-->
                                        <th><?php echo e(__('CÓDIGO')); ?></th>
                                        <th><?php echo e(__('DNI / RUC')); ?></th>
                                        <th><?php echo e(__('DATOS')); ?></th>
                                        <th><?php echo e(__('FECHA DE TICKET')); ?></th>
                                        <th><?php echo e(__('REGISTRADO')); ?></th>
                                        <th><?php echo e(__('REF.LOTE ')); ?></th>
                                        <th><?php echo e(__('ESTADO')); ?></th>
                                        <th><?php echo e(__('PRODUCTO')); ?></th>
                                        <th><?php echo e(__('PESO TOTAL')); ?></th>
                                        <th><?php echo e(__('NRO TICKET')); ?></th>
                                        <th><?php echo e(__('GUIA REMISION')); ?></th>
                                        <th><?php echo e(__('GUIA TRANSPORTE')); ?></th>
                                        
                                        <th><?php echo e(__('DESCRIPCION')); ?></th>
                                      <th style="min-width: 130px;"><?php echo e(__('CREADO POR')); ?></th>
                                        <th style="min-width: 180px;"><?php echo e(__('ACCIONES')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ingresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ingreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                            <td><?php echo e(($ingresos->currentPage() - 1) * $ingresos->perPage() + $index + 1); ?></td>
                                            <!--<td><?php echo e($ingreso->id); ?></td> -->
                                            <td><?php echo e($ingreso->codigo); ?></td>
                                            <td><?php echo e($ingreso->identificador); ?></td>
                                            <td><?php echo e($ingreso->nom_iden); ?></td>
                                            <td><?php echo e($ingreso->fecha_ingreso); ?></td>
                                             <?php
                                                $fechaIngreso = \Carbon\Carbon::parse($ingreso->fecha_ingreso);
                                                $fechaCreado = \Carbon\Carbon::parse($ingreso->created_at);
                                                $diferenciaHoras = $fechaCreado->diffInHours($fechaIngreso);
                                            ?>
                                            <td class="<?php echo e($diferenciaHoras > 24 ? 'bg-danger text-white' : ''); ?>">
                                                <?php echo e($ingreso->created_at); ?>

                                            </td>
                                            <td><?php echo e($ingreso->ref_lote); ?></td>
                                            <td>
                                                <?php
                                                $faseClass = match(strtolower($ingreso->fase)) {
                                                    'ingresado' => 'bg-success',
                                                    'blending' => 'bg-warning text-dark',
                                                    'despachado' => 'bg-orange',
                                                    'retirado' => 'bg-lightgray text-dark',
                                                    default => 'bg-secondary'
                                                };
                                            ?>
                                            
                                            <span class="badge <?php echo e($faseClass); ?>">
                                                <?php echo e(ucfirst($ingreso->fase)); ?>

                                            </span>                        </td>
                                            <td><?php echo e($ingreso->estado); ?></td>
                                            <td><?php echo e(number_format($ingreso->peso_total, 3)); ?></td>
                                            <td><?php echo e($ingreso->NroSalida); ?></td>
                                            <td><?php echo e($ingreso->guia_remision); ?></td>
                                            <td><?php echo e($ingreso->guia_transporte); ?></td>
                                           
                                            <td><?php echo e($ingreso->descripcion); ?></td>
                                            <td style="white-space: normal;"><?php echo e($ingreso->user ? $ingreso->user->name : 'Desconocido'); ?></td>

<td style="white-space: nowrap;">
    <a href="<?php echo e(route('ingresos.show', $ingreso->id)); ?>" class="btn btn-secondary btn-sm">Ver</a>
    <a class="btn btn-primary btn-sm" href="<?php echo e(route('ingresos.imprimir', $ingreso->id)); ?>">Imprimir</a>

    <?php if(strtolower($ingreso->fase) !== 'retirado'): ?>
        <a href="<?php echo e(route('ingresos.edit', $ingreso->id)); ?>" class="btn btn-warning btn-sm btn-editar">Editar</a>

        <form action="<?php echo e(route('ingresos.destroy', $ingreso->id)); ?>" method="POST" class="d-inline eliminar-registro">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger btn-sm btn-eliminar">Eliminar</button>
        </form>

        <button type="button" class="btn btn-light btn-sm retirar-btn" data-id="<?php echo e($ingreso->id); ?>">Retirar</button>
    <?php else: ?>
        <span class="badge bg-dark">Retirado</span>
    <?php endif; ?>
</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
</div>
                            <!-- Paginación centrada -->
                            <div class="d-flex justify-content-center mt-3">
                                <nav>
                                    <ul class="pagination">
                                        
                                        <?php if($ingresos->onFirstPage()): ?>
                                            <li class="page-item disabled"><span class="page-link">« Anterior</span></li>
                                        <?php else: ?>
                                            <li class="page-item"><a class="page-link" href="<?php echo e($ingresos->previousPageUrl()); ?>">« Anterior</a></li>
                                        <?php endif; ?>
                            
                                        
                                        <?php for($i = 1; $i <= $ingresos->lastPage(); $i++): ?>
                                            <li class="page-item <?php echo e($i == $ingresos->currentPage() ? 'active' : ''); ?>">
                                                <a class="page-link" href="<?php echo e($ingresos->url($i)); ?>"><?php echo e($i); ?></a>
                                            </li>
                                        <?php endfor; ?>
                            
                                        
                                        <?php if($ingresos->hasMorePages()): ?>
                                            <li class="page-item"><a class="page-link" href="<?php echo e($ingresos->nextPageUrl()); ?>">Siguiente »</a></li>
                                        <?php else: ?>
                                            <li class="page-item disabled"><span class="page-link">Siguiente »</span></li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->startPush('styles'); ?>
        <style>
            .table-orange {
                background-color: #ffcccc !important; /* rojo suave */
            }
        
            .table-lightgray {
                background-color: #f8f9fa !important; /* gris muy clarito */
            }
        
            .bg-orange {
                background-color: #ff4d4d !important; /* rojo más intenso */
                color: white !important;
            }
        
            .bg-lightgray {
                background-color: #e6e6e6 !important; /* gris clarito */
                color: #333 !important;
            }
        </style>
        <style>
    .tabla-ingresos td, .tabla-ingresos th {
        font-size: 0.75rem; /* más pequeño */
        padding: 0.3rem;     /* menos espacio */
        vertical-align: middle;
    }

    .tabla-ingresos .btn {
        padding: 0.2rem 0.4rem;
        font-size: 0.7rem;
    }

    .tabla-ingresos .badge {
        font-size: 0.7rem;
        padding: 0.3rem 0.5rem;
    }
</style>
        <?php $__env->stopPush(); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                document.querySelectorAll('.retirar-btn').forEach(button => {
                    button.addEventListener('click', function () {
                        const ingresoId = this.dataset.id;
                        const btn = this;
            
                        Swal.fire({
                            title: '¿Estás seguro?',
                            text: "Este ingreso será marcado como retirado.",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Sí, retirar',
                            cancelButtonText: 'Cancelar'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                fetch("<?php echo e(url('/ingresos')); ?>/" + ingresoId + "/retirar", {
                                    method: 'POST',
                                    headers: {
                                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json'
                                    },
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        const parentTd = btn.closest('td');
                                        parentTd.querySelector('.btn-editar')?.classList.add('d-none');
                                        parentTd.querySelector('.btn-eliminar')?.classList.add('d-none');
            
                                        // Reemplaza el botón por una etiqueta
                                        btn.outerHTML = '<span class="badge bg-lightgray text-dark">Retirado</span>';
            
                                        Swal.fire(
                                            'Retirado',
                                            'El ingreso fue retirado correctamente.',
                                            'success'
                                        );
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    Swal.fire('Error', 'Ocurrió un error al retirar el ingreso.', 'error');
                                });
                            }
                        });
                    });
                });
            });
            </script>
        <?php $__env->stopPush(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\corporacion\resources\views/ingresos/index.blade.php ENDPATH**/ ?>