<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AcActivoEstado extends Model
{
    use HasFactory;
    protected $table = 'ac_activos_estados';

}
